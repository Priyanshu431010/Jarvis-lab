import java.lang.management.ManagementFactory;
import java.lang.management.OperatingSystemMXBean;

// Python server isse chalata hai:  java SystemInfo.java   (Java 11+)
public class SystemInfo {
    public static void main(String[] args) {
        OperatingSystemMXBean os = ManagementFactory.getOperatingSystemMXBean();
        long upMin = ManagementFactory.getRuntimeMXBean().getUptime() / 60000;
        System.out.println("{"
            + "\"os\":\"" + os.getName() + " " + os.getArch() + "\","
            + "\"cores\":" + os.getAvailableProcessors() + ","
            + "\"java\":\"" + System.getProperty("java.version") + "\","
            + "\"maxMemMB\":" + (Runtime.getRuntime().maxMemory() / 1048576) + ","
            + "\"load\":" + String.valueOf(os.getSystemLoadAverage()) + ","
            + "\"upMin\":" + upMin
            + "}");
    }
}
