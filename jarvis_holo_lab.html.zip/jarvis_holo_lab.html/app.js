const $ = id => document.getElementById(id), av = $('av'), logEl = $('log'), inp = $('in');
const api = async (n, q = '') => (await fetch(`/api/${n}?q=${encodeURIComponent(q)}`)).json();
let todos = JSON.parse(localStorage.getItem('jv_todo') || '[]'), hist = [], cmdHist = [], hi = 0;

// ---------- Dock icons ----------
const DOCK = [['▶','YouTube','open youtube'],['🔍','Google','open google'],['🐙','GitHub','open github'],['✉','Gmail','open gmail'],
 ['🗺','Maps','open maps'],['💬','WhatsApp','open whatsapp'],['🎵','Spotify','open spotify'],['🧮','Calc','open calculator'],
 ['📝','Notepad','open notepad'],['💻','Terminal','open terminal'],['🛰','Scan','scan'],['🔐','Password','password'],
 ['🌐','Network','net'],['☕','Java','java'],['🧠','Holo Lab','holo'],['🎤','Voice','voice'],['☠','Hack','hack'],['❓','Help','help']];
$('dock').innerHTML = DOCK.map(([i, l, c]) => `<button data-c="${c}" title="${c}"><span>${i}</span>${l}</button>`).join('');
$('dock').onclick = e => { const b = e.target.closest('button'); if (b) run(b.dataset.c); };

// ---------- Console + voice ----------
function log(t, cls = 'j') { const d = document.createElement('div'); d.className = cls; logEl.append(d); logEl.scrollTop = 1e9;
  if (cls !== 'j') return d.textContent = t; let i = 0; (function k() { d.textContent = t.slice(0, i += 3); logEl.scrollTop = 1e9; if (i < t.length) setTimeout(k, 12); })(); }
function say(t, speak = true) {
  log('JARVIS> ' + t);
  if (!speak) return;
  try { speechSynthesis.cancel(); const u = new SpeechSynthesisUtterance(t.replace(/[\n#_*]/g, ' ')); u.rate = .95; u.pitch = .7;
    const v = speechSynthesis.getVoices().find(v => /en-(GB|IN)/.test(v.lang)); if (v) u.voice = v;
    u.onstart = () => { av.classList.add('talk'); $('state').textContent = 'SPEAKING'; };
    u.onend = () => { av.classList.remove('talk'); $('state').textContent = 'IDLE'; }; speechSynthesis.speak(u); } catch (e) {}
}
document.addEventListener('mousemove', e => { const r = av.getBoundingClientRect(), x = (e.clientX - r.left - r.width / 2) / r.width, y = (e.clientY - r.top - r.height / 2) / r.height;
  $('eyes').style.transform = `translate(${Math.max(-1, Math.min(1, x)) * 5}px,${Math.max(-1, Math.min(1, y)) * 3}px)`; });

// ---------- Commands ----------
const HELP = `COMMANDS
open <youtube|google|github|gmail|maps|whatsapp|spotify|calculator|notepad|terminal>
play <song>  |  google <query>  |  calc <2+2*5>
password [length]  |  hash <text>  |  b64 <text>
scan (localhost ports)  |  net  |  java  |  stats
todo add <task> / todo clear  |  timer <n> [sec|min]
time  |  joke  |  holo  |  voice  |  hack  |  theme green|red|blue
Voice me bolo: "Jarvis open youtube"`;
async function run(raw) {
  const c = raw.trim().toLowerCase().replace(/^(hey |ok )?jarvis[, ]*/, ''); if (!c) return; let m;
  try {
    if ((m = c.match(/^(?:open|kholo|launch)\s+(.+)/))) { const r = await api('open', m[1]); r.error ? log(r.error, 'e') : say('Opening ' + m[1] + ', sir.'); }
    else if ((m = c.match(/^(?:play|gaana)\s+(.+)/))) { await api('search', 'yt:' + m[1]); say('Playing ' + m[1] + ' on YouTube.'); }
    else if ((m = c.match(/^(?:google|search)\s+(.+)/))) { await api('search', m[1]); say('Searching for ' + m[1] + '.'); }
    else if ((m = c.match(/^(?:calc|calculate)\s+(.+)/))) { const r = await api('calc', m[1]); r.error ? log('Invalid expression', 'e') : say(m[1] + ' = ' + r.msg); }
    else if ((m = c.match(/^pass(?:word)?\s*(\d+)?/))) { const r = await api('pass', m[1] || 16); say('Secure password: ' + r.msg, false); say('Password generated.'); }
    else if ((m = c.match(/^hash\s+(.+)/))) { say('SHA-256: ' + (await api('hash', m[1])).msg, false); }
    else if ((m = c.match(/^b64\s+(.+)/))) { say('Base64: ' + (await api('b64', m[1])).msg, false); }
    else if (c === 'scan') { say('Scanning localhost ports...'); const r = await api('scan'); say(r.open.length ? 'Open ports: ' + r.open.join(', ') : 'No common ports open. System secure.'); }
    else if (c === 'net') { const r = await api('net'); say(`HOST ${r.host}\nIP   ${r.ip}\nOS   ${r.os}\nPY   ${r.python}`, false); say('Network details displayed.'); }
    else if (c === 'java') { await loadJava(); say('Java core report refreshed. Check the side panel.'); }
    else if (c === 'stats') { const s = await api('stats'); say(s.cpu == null ? 'Install psutil for CPU and RAM stats.' : `CPU ${s.cpu}%, RAM ${s.ram}%, Disk ${s.disk}%.`); }
    else if (c === 'time' || c === 'date') { const n = new Date(); say(`It is ${n.toLocaleTimeString()} on ${n.toLocaleDateString('en-IN', { dateStyle: 'full' })}.`); }
    else if (c === 'joke') say((await api('joke')).msg);
    else if (c === 'holo') { window.open('/jarvis_holo_lab.html'); say('Launching holographic lab. Ensure the file is in this folder.'); }
    else if (c === 'voice') listen();
    else if (c === 'hack') { const on = document.body.classList.toggle('red'); say(on ? 'Intrusion countermeasures active. Red alert.' : 'Back to normal, sir.'); }
    else if ((m = c.match(/^theme\s+(green|red|blue)/))) { document.body.className = m[1] === 'green' ? '' : m[1]; say('Theme ' + m[1] + ' applied.'); }
    else if ((m = c.match(/^todo add\s+(.+)/))) { todos.push(m[1]); saveTodo(); say('Mission added.'); }
    else if (c === 'todo clear') { todos = []; saveTodo(); say('Missions cleared.'); }
    else if ((m = c.match(/^timer\s+(\d+)\s*(sec|s|min|m)?/))) { const ms = m[1] * (/^m/.test(m[2] || '') ? 60000 : 1000); say(`Timer set for ${m[1]} ${m[2] || 'sec'}.`); setTimeout(() => say('Sir, your timer has finished.'), ms); }
    else if (c === 'help') say(HELP, false);
    else if (/^(hi|hello|namaste)/.test(c)) say('Hello sir. How may I assist you?');
    else log("Command not recognized. Type 'help'.", 'e');
  } catch (e) { log('Backend offline. Run: python server.py', 'e'); }
}
inp.addEventListener('keydown', e => {
  if (e.key === 'Enter' && inp.value) { log('root@jarvis:~# ' + inp.value, 'u'); cmdHist.push(inp.value); hi = cmdHist.length; run(inp.value); inp.value = ''; }
  else if (e.key === 'ArrowUp' && hi > 0) inp.value = cmdHist[--hi];
  else if (e.key === 'ArrowDown') inp.value = cmdHist[++hi] || '';
});

// ---------- Mic ----------
const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
function listen() {
  if (!SR) return log('Voice input ke liye Chrome use karo.', 'e');
  const r = new SR(); r.lang = 'en-IN'; $('mic').classList.add('on'); $('state').textContent = 'LISTENING';
  r.onresult = e => { const t = e.results[0][0].transcript; log('root@jarvis:~# ' + t + ' 🎤', 'u'); run(t); };
  r.onend = () => { $('mic').classList.remove('on'); $('state').textContent = 'IDLE'; }; r.start();
}
$('mic').onclick = listen;

// ---------- Todo / clock ----------
function saveTodo() { localStorage.setItem('jv_todo', JSON.stringify(todos)); $('todo').innerHTML = todos.map(t => `<li>▸ ${t.replace(/</g, '&lt;')}</li>`).join('') || '<li>No active missions</li>'; }
saveTodo(); setInterval(() => $('clock').textContent = new Date().toLocaleTimeString(), 1000);

// ---------- System panel ----------
const gc = $('graph').getContext('2d');
async function poll() {
  try { const s = await api('stats');
    [['cpu', s.cpu], ['ram', s.ram], ['disk', s.disk], ['bat', s.bat]].forEach(([k, v]) => { $('b-' + k).style.width = (v ?? 0) + '%'; $('v-' + k).textContent = v == null ? 'n/a' : Math.round(v) + '%'; });
    hist.push(s.cpu ?? 0); hist = hist.slice(-40); gc.clearRect(0, 0, 260, 60); gc.strokeStyle = getComputedStyle(document.body).getPropertyValue('--c'); gc.beginPath();
    hist.forEach((v, i) => gc[i ? 'lineTo' : 'moveTo'](i * 6.6, 58 - v * .56)); gc.stroke();
  } catch (e) { $('mode').textContent = '// BACKEND OFFLINE - run python server.py'; }
}
async function loadJava() { try { const j = await api('java'); $('java').textContent = j.error || `OS    ${j.os}\nCORES ${j.cores}\nJAVA  ${j.java}\nMEM   ${j.maxMemMB} MB\nLOAD  ${j.load}`; } catch (e) { $('java').textContent = 'offline'; } }
setInterval(poll, 2000); poll(); loadJava();

// ---------- Matrix rain ----------
const rc = $('rain'), rx = rc.getContext('2d'); let drops = [];
function rz() { rc.width = innerWidth; rc.height = innerHeight; drops = Array(Math.floor(rc.width / 16)).fill(1); } rz(); addEventListener('resize', rz);
setInterval(() => { rx.fillStyle = 'rgba(2,10,8,.13)'; rx.fillRect(0, 0, rc.width, rc.height); rx.fillStyle = getComputedStyle(document.body).getPropertyValue('--c'); rx.font = '15px monospace';
  drops.forEach((y, i) => { rx.fillText(String.fromCharCode(0x30A0 + Math.random() * 96), i * 16, y * 16); drops[i] = y * 16 > rc.height && Math.random() > .97 ? 0 : y + 1; }); }, 55);

// ---------- Boot ----------
const h = new Date().getHours();
setTimeout(() => say(`Good ${h < 12 ? 'morning' : h < 17 ? 'afternoon' : 'evening'}, sir. All systems online. Type help to see what I can do.`), 700);
