"""JARVIS backend - sirf localhost par chalta hai. Run: python server.py  (optional: pip install psutil)"""
import http.server as hs, json, os, platform, shutil, socket, hashlib, base64, ast, operator, random, string, subprocess, webbrowser, urllib.parse as up
try: import psutil
except ImportError: psutil = None

ROOT = os.path.dirname(os.path.abspath(__file__)); OS = platform.system(); PORT = 8765
SITES = dict(youtube='https://youtube.com', google='https://google.com', github='https://github.com', gmail='https://mail.google.com',
             maps='https://maps.google.com', whatsapp='https://web.whatsapp.com', instagram='https://instagram.com', spotify='https://open.spotify.com')
APPS = {'Windows': dict(calculator='calc', notepad='notepad', explorer='explorer', terminal='start cmd'),
        'Darwin': dict(calculator='open -a Calculator', notepad='open -a TextEdit', explorer='open ~', terminal='open -a Terminal'),
        'Linux': dict(calculator='gnome-calculator', notepad='gedit', explorer='xdg-open ~', terminal='x-terminal-emulator')}.get(OS, {})
OPS = {ast.Add: operator.add, ast.Sub: operator.sub, ast.Mult: operator.mul, ast.Div: operator.truediv, ast.Mod: operator.mod, ast.Pow: operator.pow, ast.USub: operator.neg}
JOKES = ["Why do programmers prefer dark mode? Because light attracts bugs.", "There are 10 types of people: those who understand binary and those who don't.",
         "I would tell you a UDP joke, but you might not get it.", "A SQL query walks into a bar, walks up to two tables and asks: can I join you?"]
_java = {}

def ev(n):
    if isinstance(n, ast.Constant) and isinstance(n.value, (int, float)): return n.value
    if isinstance(n, ast.BinOp):
        a, b = ev(n.left), ev(n.right)
        if isinstance(n.op, ast.Pow) and abs(b) > 100: raise ValueError('power too big')
        return OPS[type(n.op)](a, b)
    if isinstance(n, ast.UnaryOp): return OPS[type(n.op)](ev(n.operand))
    raise ValueError('invalid expression')

def java():
    if not _java:
        try: _java.update(json.loads(subprocess.run(['java', os.path.join(ROOT, 'SystemInfo.java')], capture_output=True, text=True, timeout=25).stdout))
        except Exception: _java['error'] = 'Java install nahi hai ya fail hua'
    return _java

def stats():
    o = {'disk': round(shutil.disk_usage(ROOT).used / shutil.disk_usage(ROOT).total * 100)}
    if psutil:
        b = psutil.sensors_battery()
        o.update(cpu=psutil.cpu_percent(), ram=psutil.virtual_memory().percent, bat=round(b.percent) if b else None)
    return o

def net():
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try: s.connect(('8.8.8.8', 80)); ip = s.getsockname()[0]
    except OSError: ip = '127.0.0.1'
    return {'host': socket.gethostname(), 'ip': ip, 'os': f'{OS} {platform.release()}', 'python': platform.python_version()}

def scan():  # sirf aapki apni machine (127.0.0.1)
    r = []
    for p in (21, 22, 80, 135, 139, 443, 445, 3306, 3389, 5432, 8000, 8080, 8765):
        s = socket.socket(); s.settimeout(.15)
        if s.connect_ex(('127.0.0.1', p)) == 0: r.append(p)
        s.close()
    return {'open': r}

def api(name, q):
    if name == 'stats': return stats()
    if name == 'java': return java()
    if name == 'net': return net()
    if name == 'scan': return scan()
    if name == 'joke': return {'msg': random.choice(JOKES)}
    if name == 'calc': return {'msg': str(ev(ast.parse(q, mode='eval').body))}
    if name == 'pass': return {'msg': ''.join(random.SystemRandom().choice(string.ascii_letters + string.digits + '!@#$%&*') for _ in range(int(q or 16)))}
    if name == 'hash': return {'msg': hashlib.sha256(q.encode()).hexdigest()}
    if name == 'b64': return {'msg': base64.b64encode(q.encode()).decode()}
    if name == 'search':
        yt = q.startswith('yt:'); q = q[3:] if yt else q
        webbrowser.open(('https://www.youtube.com/results?search_query=' if yt else 'https://www.google.com/search?q=') + up.quote(q)); return {'msg': 'ok'}
    if name == 'open':
        q = q.lower().strip()
        if q in SITES: webbrowser.open(SITES[q]); return {'msg': 'ok'}
        if q in APPS: subprocess.Popen(APPS[q], shell=True); return {'msg': 'ok'}  # sirf whitelisted commands
        return {'error': 'Unknown target: ' + q}
    return {'error': 'unknown api'}

class H(hs.SimpleHTTPRequestHandler):
    def __init__(s, *a, **k): super().__init__(*a, directory=ROOT, **k)
    def log_message(s, *a): pass
    def do_GET(s):
        u = up.urlparse(s.path)
        if not u.path.startswith('/api/'): return super().do_GET()
        try: out = api(u.path[5:], up.parse_qs(u.query).get('q', [''])[0])
        except Exception as e: out = {'error': str(e)}
        b = json.dumps(out).encode(); s.send_response(200); s.send_header('Content-Type', 'application/json'); s.end_headers(); s.wfile.write(b)

if __name__ == '__main__':
    print(f'JARVIS online -> http://127.0.0.1:{PORT}')
    webbrowser.open(f'http://127.0.0.1:{PORT}')
    hs.ThreadingHTTPServer(('127.0.0.1', PORT), H).serve_forever()
